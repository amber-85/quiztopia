import{v4 as uuid4} from "uuid";
import {PutCommand} from "@aws-sdk/lib-dynamodb";
import {dynamoDb} from "../../services/db.mjs";
import dotenv from "dotenv";
import {logger} from "../../middleware/logger.mjs"
import {errorHandler} from "../../middleware/errorHandler.mjs"
import middy from "@middy/core";
import jsonBodyParser from "@middy/http-json-body-parser";
import { authMiddleware } from "../../middleware/authMiddleware.mjs";

dotenv.config();

export const createQuizFn=async(event)=>{
    const {question,latitude,longitude,options}=event.body;
    const creatorId=event.user.userId;

    //validate inputs
    if(!question||!options||options.length<2||!latitude||!longitude){
        return {statusCode:400, body:JSON.stringify({error:"Invalid input data"})};
    }
    const quizId=uuid4();
    const createdAt=new Date().toISOString();

    //quiz metadata
    const quizItem={
        PK:`QUIZ#${quizId}`,
        SK:"META",
        ItemType:"Quiz",
        quizId,
        question,
        latitude: Number(latitude),
        longitude: Number(longitude),
        creatorId,
        createdAt
    };

    await dynamoDb.send(new PutCommand({TableName:process.env.QUIZGAME_TABLE, Item:quizItem}));

    //quiz options

    for (let i=0; i<options.length; i++){
        const option=options[i];

        //check correct answer validity
        if (typeof option.is_correct!=="boolean") {
            return {statusCode:400, body:JSON.stringify({error:" Invalid option format"})};
        }

        const optionItem={
            PK:`QUIZ#${quizId}`,
            SK:`OPTION#${i+1}`,
            ItemType:"Option",
            optionId:`${i+1}`,
            option_text:option.text,
            is_correct:option.is_correct
        };
        await dynamoDb.send(new PutCommand({TableName:process.env.QUIZGAME_TABLE, Item:optionItem}));
    }

    return {statusCode:201, body:JSON.stringify({message:"Quiz created successfully", quizId})};
}

export const handler=middy(createQuizFn)
    .use(jsonBodyParser())
    .use(authMiddleware())
    .use(logger())
    .use(errorHandler());